var x=200;
var y=200 
var r=50;
function setup() {
createCanvas(400, 400);
}

function draw() {
background(220);
if(mouseIsPressed&&dist(mouseX,mouseY,x,y)<r){ 
x=mouseX;
y=mouseY;
}
ellipse(x,y,r,r);
}